
import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useCustomer } from '@/contexts/CustomerContext';
import { supabase } from '@/lib/supabase';
import QuoteCard from '@/components/customer/QuoteCard';
import RescheduleModal from '@/components/customer/RescheduleModal';
import { Truck, LogOut, FileText, Clock, CheckCircle, Package, Loader2, Plus } from 'lucide-react';

interface Quote {
  id: string;
  reference_number: string;
  status: string;
  dumpster_size: string;
  address: string;
  city: string;
  total_price: number;
  delivery_date?: string;
  delivery_time_slot?: string;
  pickup_date?: string;
  created_at: string;
}

export default function CustomerDashboard() {
  const { customer, logout, isLoading: authLoading } = useCustomer();
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [rescheduleQuote, setRescheduleQuote] = useState<Quote | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!authLoading && !customer) {
      navigate('/customer/login');
    }
  }, [customer, authLoading, navigate]);

  useEffect(() => {
    if (customer) fetchQuotes();
  }, [customer]);

  const fetchQuotes = async () => {
    setIsLoading(true);
    try {
      const { data } = await supabase.functions.invoke('customer-quotes', {
        body: { action: 'list', customerId: customer?.id, email: customer?.email }
      });
      setQuotes(data?.quotes || []);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const downloadInvoice = (quote: Quote) => {
    const invoice = `
INVOICE - ${quote.reference_number}
================================
Date: ${new Date().toLocaleDateString()}
Customer: ${customer?.name}
Email: ${customer?.email}

SERVICE DETAILS
---------------
Dumpster Size: ${quote.dumpster_size} Yard
Delivery Address: ${quote.address}, ${quote.city}
${quote.delivery_date ? `Delivery Date: ${new Date(quote.delivery_date).toLocaleDateString()}` : ''}
${quote.delivery_time_slot ? `Time Slot: ${quote.delivery_time_slot}` : ''}
${quote.pickup_date ? `Pickup Date: ${new Date(quote.pickup_date).toLocaleDateString()}` : ''}

TOTAL: $${quote.total_price?.toFixed(2)}
================================
Thank you for your business!
    `.trim();
    
    const blob = new Blob([invoice], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `invoice-${quote.reference_number}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleLogout = () => { logout(); navigate('/'); };

  const activeQuotes = quotes.filter(q => ['pending', 'reviewed', 'approved', 'scheduled'].includes(q.status));
  const completedQuotes = quotes.filter(q => q.status === 'completed');

  if (authLoading) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-orange-500" /></div>;

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center">
              <Truck className="w-6 h-6 text-white" />
            </div>
            <span className="font-bold text-xl">My Account</span>
          </Link>
          <div className="flex items-center gap-4">
            <span className="text-gray-600 hidden sm:block">Welcome, {customer?.name}</span>
            <Button variant="outline" size="sm" onClick={handleLogout}><LogOut className="w-4 h-4 mr-2" /> Logout</Button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total Quotes', value: quotes.length, icon: FileText, color: 'bg-blue-500' },
            { label: 'Active', value: activeQuotes.length, icon: Clock, color: 'bg-orange-500' },
            { label: 'Completed', value: completedQuotes.length, icon: CheckCircle, color: 'bg-green-500' },
            { label: 'Scheduled', value: quotes.filter(q => q.status === 'scheduled').length, icon: Package, color: 'bg-purple-500' }
          ].map((stat, i) => (
            <Card key={i}>
              <CardContent className="p-4 flex items-center gap-4">
                <div className={`w-12 h-12 ${stat.color} rounded-lg flex items-center justify-center`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
                <div><p className="text-2xl font-bold">{stat.value}</p><p className="text-sm text-gray-500">{stat.label}</p></div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Your Quotes</h2>
          <Link to="/"><Button className="bg-orange-500 hover:bg-orange-600"><Plus className="w-4 h-4 mr-2" /> New Quote</Button></Link>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-orange-500" /></div>
        ) : quotes.length === 0 ? (
          <Card><CardContent className="p-12 text-center">
            <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">No quotes yet</h3>
            <p className="text-gray-500 mb-4">Get started by requesting your first quote</p>
            <Link to="/"><Button className="bg-orange-500 hover:bg-orange-600">Get a Quote</Button></Link>
          </CardContent></Card>
        ) : (
          <Tabs defaultValue="active">
            <TabsList className="mb-6"><TabsTrigger value="active">Active ({activeQuotes.length})</TabsTrigger><TabsTrigger value="completed">Completed ({completedQuotes.length})</TabsTrigger><TabsTrigger value="all">All ({quotes.length})</TabsTrigger></TabsList>
            {['active', 'completed', 'all'].map(tab => (
              <TabsContent key={tab} value={tab}>
                <div className="grid md:grid-cols-2 gap-4">
                  {(tab === 'active' ? activeQuotes : tab === 'completed' ? completedQuotes : quotes).map(quote => (
                    <QuoteCard key={quote.id} quote={quote} onReschedule={setRescheduleQuote} onDownloadInvoice={downloadInvoice} />
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        )}
      </main>

      <RescheduleModal quote={rescheduleQuote} customerId={customer?.id || ''} onClose={() => setRescheduleQuote(null)} onSuccess={fetchQuotes} />
    </div>
  );
}
