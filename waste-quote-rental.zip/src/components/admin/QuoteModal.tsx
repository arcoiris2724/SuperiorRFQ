import { useState } from 'react';
import { Quote } from '@/pages/admin/AdminDashboard';
import { supabase } from '@/lib/supabase';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Phone, Mail, Loader2, Hash, Truck, Send, Camera, MapPin, Navigation, ExternalLink } from 'lucide-react';

interface Props { quote: Quote; onClose: () => void; onUpdate: () => void; }

const timeSlots = ['8:00 AM - 10:00 AM', '10:00 AM - 12:00 PM', '12:00 PM - 2:00 PM', '2:00 PM - 4:00 PM', '4:00 PM - 6:00 PM'];

export default function QuoteModal({ quote, onClose, onUpdate }: Props) {
  const [status, setStatus] = useState(quote.status);
  const [notes, setNotes] = useState(quote.notes || '');
  const [deliveryDate, setDeliveryDate] = useState(quote.delivery_date || '');
  const [deliveryTimeSlot, setDeliveryTimeSlot] = useState(quote.delivery_time_slot || '');
  const [pickupDate, setPickupDate] = useState(quote.pickup_date || '');
  const [saving, setSaving] = useState(false);
  const [sendEmail, setSendEmail] = useState(true);

  const statusChanged = status !== quote.status;
  const photos = quote.photos || [];
  const hasLocation = quote.delivery_lat && quote.delivery_lng;
  const mapsUrl = hasLocation ? `https://www.google.com/maps/search/?api=1&query=${quote.delivery_lat},${quote.delivery_lng}` : '';
  const directionsUrl = hasLocation ? `https://www.google.com/maps/dir/?api=1&destination=${quote.delivery_lat},${quote.delivery_lng}` : '';
  const mapEmbedUrl = hasLocation ? `https://www.openstreetmap.org/export/embed.html?bbox=${quote.delivery_lng! - 0.005}%2C${quote.delivery_lat! - 0.003}%2C${quote.delivery_lng! + 0.005}%2C${quote.delivery_lat! + 0.003}&layer=mapnik&marker=${quote.delivery_lat}%2C${quote.delivery_lng}` : '';

  const handleSave = async () => {
    setSaving(true);
    await supabase.functions.invoke('admin-quotes', {
      body: { action: 'update', quoteId: quote.id, status, notes, deliveryDate: deliveryDate || null, 
        deliveryTimeSlot: deliveryTimeSlot || null, pickupDate: pickupDate || null,
        sendEmail: statusChanged && sendEmail, baseUrl: window.location.origin }
    });
    setSaving(false);
    onUpdate();
    onClose();
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2"><Hash className="w-5 h-5" />{quote.reference_number}</span>
            <Badge className="text-lg px-3 py-1 bg-[#1A8B06]">${quote.total_price}</Badge>
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-3">
            <h3 className="font-semibold text-gray-700 border-b pb-2">Customer</h3>
            <p className="font-medium">{quote.customer_name}</p>
            <p className="flex items-center gap-2 text-sm text-gray-600"><Mail className="w-4 h-4" />{quote.customer_email}</p>
            <p className="flex items-center gap-2 text-sm text-gray-600"><Phone className="w-4 h-4" />{quote.customer_phone}</p>
          </div>
          <div className="space-y-3">
            <h3 className="font-semibold text-gray-700 border-b pb-2">Details</h3>
            <p className="text-sm"><span className="text-gray-500">Location:</span> {quote.location}</p>
            <p className="text-sm"><span className="text-gray-500">Size:</span> {quote.size} Yard</p>
            <p className="text-sm"><span className="text-gray-500">Material:</span> {quote.material}</p>
          </div>
        </div>

        {(quote.delivery_address || hasLocation) && (
          <div className="pt-4 border-t">
            <div className="flex items-center gap-2 mb-3"><MapPin className="w-5 h-5 text-[#1A8B06]" /><h3 className="font-semibold text-gray-700">Delivery Location</h3></div>
            {quote.delivery_address && <p className="text-sm text-gray-700 mb-3">{quote.delivery_address}</p>}
            {hasLocation && (
              <div className="rounded-lg overflow-hidden border">
                <iframe src={mapEmbedUrl} width="100%" height="180" style={{ border: 0 }} loading="lazy" title="Delivery Location" />
                <div className="flex gap-2 p-2 bg-gray-50">
                  <a href={directionsUrl} target="_blank" rel="noopener noreferrer" className="flex-1">
                    <Button variant="outline" size="sm" className="w-full gap-2"><Navigation className="w-4 h-4" />Directions</Button>
                  </a>
                  <a href={mapsUrl} target="_blank" rel="noopener noreferrer" className="flex-1">
                    <Button variant="outline" size="sm" className="w-full gap-2"><ExternalLink className="w-4 h-4" />Open Map</Button>
                  </a>
                </div>
              </div>
            )}
          </div>
        )}

        {photos.length > 0 && (
          <div className="pt-4 border-t">
            <div className="flex items-center gap-2 mb-3"><Camera className="w-5 h-5 text-[#1A8B06]" /><h3 className="font-semibold text-gray-700">Photos ({photos.length})</h3></div>
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
              {photos.map((url, i) => (
                <a key={i} href={url} target="_blank" rel="noopener noreferrer" className="block">
                  <img src={url} alt={`Photo ${i+1}`} className="w-full aspect-square object-cover rounded-lg border hover:opacity-80 transition-opacity" />
                </a>
              ))}
            </div>
          </div>
        )}

        <div className="space-y-4 pt-4 border-t">
          <div className="flex items-center gap-2 text-[#1A8B06]"><Truck className="w-5 h-5" /><h3 className="font-semibold">Scheduling</h3></div>
          <div className="grid md:grid-cols-2 gap-4">
            <div><label className="text-sm font-medium">Delivery Date</label><Input type="date" value={deliveryDate} onChange={e => setDeliveryDate(e.target.value)} min={new Date().toISOString().split('T')[0]} /></div>
            <div><label className="text-sm font-medium">Time Slot</label>
              <Select value={deliveryTimeSlot} onValueChange={setDeliveryTimeSlot}><SelectTrigger><SelectValue placeholder="Select time" /></SelectTrigger><SelectContent>{timeSlots.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select>
            </div>
            <div><label className="text-sm font-medium">Pickup Date</label><Input type="date" value={pickupDate} onChange={e => setPickupDate(e.target.value)} min={deliveryDate || new Date().toISOString().split('T')[0]} /></div>
          </div>
        </div>

        <div className="space-y-4 pt-4 border-t">
          <div><label className="text-sm font-medium">Status</label>
            <Select value={status} onValueChange={setStatus}><SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">Pending</SelectItem><SelectItem value="reviewed">Reviewed</SelectItem>
                <SelectItem value="approved">Approved</SelectItem><SelectItem value="scheduled">Scheduled</SelectItem>
                <SelectItem value="delivered">Delivered</SelectItem><SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {statusChanged && (
            <div className="flex items-center space-x-2 bg-blue-50 p-3 rounded-lg">
              <Checkbox id="sendEmail" checked={sendEmail} onCheckedChange={(c) => setSendEmail(!!c)} />
              <label htmlFor="sendEmail" className="text-sm font-medium flex items-center gap-2 cursor-pointer"><Send className="w-4 h-4 text-blue-600" />Send email notification</label>
            </div>
          )}
          <div><label className="text-sm font-medium">Notes</label><Textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} placeholder="Internal notes..." /></div>
          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving} className="bg-[#1A8B06] hover:bg-[#106203]">{saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}Save</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
