import React, { useRef } from 'react';
import Navbar from './sections/Navbar';
import { Hero } from './sections/Hero';
import { QuoteBuilder } from './quote/QuoteBuilder';
import { ServiceAreas } from './sections/ServiceAreas';
import SizeGuide from './sections/SizeGuide';
import SizeComparisonChart from './sections/SizeComparisonChart';
import { PricingTable } from './sections/PricingTable';
import FAQ from './sections/FAQ';
import { Footer } from './sections/Footer';
import WhatsAppButton from './WhatsAppButton';

const AppLayout: React.FC = () => {
  const quoteRef = useRef<HTMLDivElement>(null);

  const scrollToQuote = () => {
    quoteRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-100">
      <Navbar onGetQuote={scrollToQuote} />
      <Hero onGetQuote={scrollToQuote} />
      
      <section ref={quoteRef} className="py-12 px-4 bg-slate-100">
        <QuoteBuilder />
      </section>

      <SizeGuide onGetQuote={scrollToQuote} />
      <SizeComparisonChart />
      <ServiceAreas />
      <PricingTable />
      <FAQ />
      <Footer />
      
      {/* WhatsApp Floating Button */}
      <WhatsAppButton />
    </div>
  );
};

export default AppLayout;
