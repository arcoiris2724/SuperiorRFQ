import React from 'react';
import { Star } from 'lucide-react';

const testimonials = [
  {
    name: 'Mike R.',
    location: 'Huntington, NY',
    text: 'Best dumpster rental experience ever. Delivered on time, picked up when promised. Will definitely use again for my next project.',
    rating: 5
  },
  {
    name: 'Sarah L.',
    location: 'Garden City, NY',
    text: 'The quote builder made it so easy to understand pricing. No surprises, no hidden fees. Highly recommend!',
    rating: 5
  },
  {
    name: 'Tom K.',
    location: 'Babylon, NY',
    text: 'Used them for a major renovation. The 30-yard was perfect. Great customer service when I needed to extend my rental.',
    rating: 5
  }
];

const Testimonials: React.FC = () => {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            What Our Customers Say
          </h2>
          <p className="text-xl text-gray-600">
            Join thousands of satisfied customers across Long Island
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index}
              className="bg-gray-50 rounded-xl p-8 relative"
            >
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="text-gray-700 mb-6 italic">"{testimonial.text}"</p>
              <div>
                <p className="font-semibold text-gray-900">{testimonial.name}</p>
                <p className="text-sm text-gray-500">{testimonial.location}</p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <div className="inline-flex items-center gap-4 bg-green-50 rounded-full px-6 py-3">
            <div className="flex gap-1">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-5 h-5 fill-green-500 text-green-500" />
              ))}
            </div>
            <span className="text-green-800 font-semibold">4.9/5 from 2,000+ reviews</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
